package io.swagger.codegen.v3.auth;

public interface AuthMethod {
    String getType();

    void setType(String type);
}