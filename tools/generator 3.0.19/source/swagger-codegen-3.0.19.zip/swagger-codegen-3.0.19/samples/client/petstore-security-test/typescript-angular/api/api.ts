export * from './fake.service';
import { FakeService } from './fake.service';
export const APIS = [FakeService];
