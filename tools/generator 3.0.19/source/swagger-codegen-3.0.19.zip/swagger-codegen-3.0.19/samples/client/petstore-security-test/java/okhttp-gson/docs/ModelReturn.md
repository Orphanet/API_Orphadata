
# ModelReturn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_return** | **Integer** | property description  *_/ &#39; \&quot; &#x3D;end -- \\r\\n \\n \\r |  [optional]



