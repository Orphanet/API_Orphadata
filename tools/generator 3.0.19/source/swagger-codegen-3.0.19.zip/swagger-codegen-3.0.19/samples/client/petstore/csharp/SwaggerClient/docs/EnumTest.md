# IO.Swagger.Model.EnumTest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnumString** | **string** |  | [optional] 
**EnumInteger** | **int?** |  | [optional] 
**EnumNumber** | **double?** |  | [optional] 
**OuterEnum** | **OuterEnum** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

