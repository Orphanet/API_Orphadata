# IO.Swagger.Model.Capitalization
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SmallCamel** | **string** |  | [optional] 
**CapitalCamel** | **string** |  | [optional] 
**SmallSnake** | **string** |  | [optional] 
**CapitalSnake** | **string** |  | [optional] 
**SCAETHFlowPoints** | **string** |  | [optional] 
**ATT_NAME** | **string** | Name of the pet  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

