# IO.Swagger.Model.Body4
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnumFormStringArray** | **List&lt;string&gt;** | Form parameter enum test (string array) | [optional] 
**EnumFormString** | **string** | Form parameter enum test (string) | [optional] [default to EnumFormStringEnum.Efg]
**EnumQueryDouble** | **double?** | Query parameter enum test (double) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

