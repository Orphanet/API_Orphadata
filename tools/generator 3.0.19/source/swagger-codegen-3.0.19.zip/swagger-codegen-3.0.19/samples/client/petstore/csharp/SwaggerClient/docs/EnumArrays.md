# IO.Swagger.Model.EnumArrays
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**JustSymbol** | **string** |  | [optional] 
**ArrayEnum** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

