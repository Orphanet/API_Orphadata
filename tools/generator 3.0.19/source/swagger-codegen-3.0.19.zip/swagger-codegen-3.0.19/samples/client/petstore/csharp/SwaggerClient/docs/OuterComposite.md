# IO.Swagger.Model.OuterComposite
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MyNumber** | [**OuterNumber**](OuterNumber.md) |  | [optional] 
**MyString** | [**OuterString**](OuterString.md) |  | [optional] 
**MyBoolean** | [**OuterBoolean**](OuterBoolean.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

