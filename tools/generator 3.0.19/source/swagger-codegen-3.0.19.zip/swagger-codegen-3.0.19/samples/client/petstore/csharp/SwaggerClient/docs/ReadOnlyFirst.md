# IO.Swagger.Model.ReadOnlyFirst
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bar** | **string** |  | [optional] 
**Baz** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

