# IO.Swagger.Model.ArrayOfArrayOfNumberOnly
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArrayArrayNumber** | **List&lt;List&lt;decimal?&gt;&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

