#!/usr/bin/env python3


from swagger_server import *

if __name__ == '__main__':
    API_main.main()
